"""The conversational agent.

Two things here are worth reading closely.

**Clarifying questions are chosen by counterfactual information gain, not by a checklist.**
For each unknown slot the agent fills it with two plausible extreme values, re-runs the
full analysis under each hypothesis, and measures how much the recommendation set moves
(Jaccard distance) and how much the diagnosis moves. A slot that does not change the
answer is not worth a question. This is why the agent asks about pH on an unclassified
soil but not about slope on a paddy.

**The agent answers before it asks.** It gives a provisional analysis from what it
already has, states the confidence cap caused by the missing data, and then asks. A
system that refuses to answer until a form is complete is a form, not an advisor.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..kb.retriever import Retriever
from ..reasoning.engine import analyse
from ..schemas import (
    Analysis,
    ChatTurn,
    ClarifyingQuestion,
    ClimateZone,
    LandUse,
    SiteProfile,
)
from .state import SessionState, SessionStore

# Two plausible extremes per slot: the counterfactual probe.
PROBES: dict[str, tuple[Any, Any]] = {
    "soc_pct": (0.3, 1.4),
    "ph": (5.0, 8.6),
    "rainfall_mm": (350.0, 1500.0),
    "climate_zone": (ClimateZone.semi_arid, ClimateZone.humid),
    "land_use": (LandUse.cropland, LandUse.pasture),
    "semi_natural_pct": (5.0, 40.0),
    "slope_pct": (0.5, 9.0),
    "cropping_pattern": ("monoculture", "mixed rotation"),
    "tree_density_per_ha": (1.0, 45.0),
    "irrigation_source": ("groundwater", "rainfed"),
}

QUESTION_TEXT: dict[str, tuple[str, str, str, list[str]]] = {
    "soc_pct": (
        "What is the soil organic carbon, as a percentage? A soil health card figure is fine.",
        "Below about 0.5% the soil is structurally depleted and carbon practices are the "
        "priority; above 1% they are not, and the constraint is elsewhere.",
        "number (%)", [],
    ),
    "ph": (
        "What is the soil pH?",
        "pH decides whether acidity or sodicity is capping root depth. Below 5.5 nothing "
        "involving legumes will work until it is corrected; above 8.4 the problem is usually "
        "clay dispersion rather than rainfall.",
        "number", [],
    ),
    "rainfall_mm": (
        "Roughly how much rainfall does the site get in a year, in mm?",
        "Rainfall sets whether adding transpiring biomass helps or competes with the crop; "
        "the threshold sits near 400 mm.",
        "number (mm)", [],
    ),
    "climate_zone": (
        "Which moisture regime is the site in?",
        "The aridity class determines the binding constraint, and therefore which of two "
        "opposite recommendations is correct.",
        "choice", ["arid", "semi_arid", "sub_humid", "humid", "temperate"],
    ),
    "land_use": (
        "What is the land currently used for?",
        "Land use gates the entire candidate set; advice for a paddy and for rangeland "
        "share almost nothing.",
        "choice", ["cropland", "paddy", "orchard", "pasture", "forest", "agroforestry",
                   "degraded_land", "village_commons", "wetland"],
    ),
    "semi_natural_pct": (
        "Roughly what share of the surrounding landscape is still under natural vegetation - "
        "scrub, woodland, grassland, wetland? A rough percentage is enough.",
        "Below about 20% there is no species pool to recolonise a restored margin, so field-scale "
        "measures under-deliver and connectivity has to come first.",
        "number (%)", [],
    ),
    "slope_pct": (
        "Is the land flat or sloping, and roughly what gradient?",
        "Contour structures only work above about 1% slope, and on flat land they waterlog.",
        "number (%)", [],
    ),
    "cropping_pattern": (
        "Is it a single crop repeated, or a rotation/intercrop?",
        "Monoculture is a structural cause of low diversity that no soil amendment can offset.",
        "choice", ["monoculture", "rotation", "intercrop", "mixed"],
    ),
    "tree_density_per_ha": (
        "Roughly how many trees per hectare are there inside the fields, not counting boundaries?",
        "In-field canopy is what supports bird and arthropod guilds that boundary trees do not.",
        "number", [],
    ),
    "irrigation_source": (
        "Where does irrigation water come from - borewell, canal, tank, or is it rainfed?",
        "If it is groundwater under drawdown, crop choice dominates every efficiency measure.",
        "choice", ["groundwater", "canal", "tank", "rainfed"],
    ),
}


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 0.0
    return 1.0 - len(a & b) / len(a | b)


@dataclass
class AgentResult:
    analysis: Analysis
    questions: list[ClarifyingQuestion]
    changes: list[str]


class BioIntelAgent:
    def __init__(self, retriever: Retriever | None = None, store: SessionStore | None = None) -> None:
        self.retriever = retriever or Retriever()
        self.store = store or SessionStore()

    # --- clarifying questions ------------------------------------------
    def information_gain(
        self, profile: SiteProfile, user_text: str, slot: str, baseline: Analysis
    ) -> float:
        lo, hi = PROBES[slot]
        sets: list[set[str]] = []
        diags: list[set[str]] = []
        for value in (lo, hi):
            hypo = profile.model_copy(deep=True)
            setattr(hypo, slot, value)
            a = analyse(hypo, user_text, retriever=self.retriever)
            sets.append({r.card_id for r in a.recommendations})
            diags.append(set(a.diagnosis.limiting_factors))
        rec_shift = _jaccard(sets[0], sets[1])
        diag_shift = _jaccard(diags[0], diags[1])
        base = {r.card_id for r in baseline.recommendations}
        from_base = max(_jaccard(base, sets[0]), _jaccard(base, sets[1]))
        return round(0.5 * rec_shift + 0.25 * diag_shift + 0.25 * from_base, 4)

    def choose_questions(
        self, state: SessionState, user_text: str, baseline: Analysis, limit: int = 3
    ) -> list[ClarifyingQuestion]:
        known = state.profile.known_slots()
        candidates = [s for s in PROBES if s not in known and s not in state.asked_slots]
        scored: list[tuple[float, str]] = []
        for slot in candidates:
            try:
                gain = self.information_gain(state.profile, user_text, slot, baseline)
            except Exception:  # noqa: BLE001 - a probe must never break the reply
                gain = 0.0
            scored.append((gain, slot))
        scored.sort(reverse=True)

        out: list[ClarifyingQuestion] = []
        for gain, slot in scored:
            if gain < 0.05 or len(out) >= limit:
                break
            q, why, typ, opts = QUESTION_TEXT[slot]
            out.append(
                ClarifyingQuestion(
                    slot=slot, question=q, why_it_matters=why,
                    expected_type=typ, options=opts, information_gain=gain,
                )
            )
        for q in out:
            state.asked_slots.add(q.slot)
        return out

    # --- main turn ------------------------------------------------------
    def handle(
        self,
        session_id: str,
        message: str = "",
        structured: dict[str, Any] | None = None,
        ask_questions: bool = True,
    ) -> AgentResult:
        state = self.store.get(session_id)
        changes: list[str] = []
        if structured:
            changes += state.ingest_structured(structured)
        if message:
            changes += state.ingest_text(message)
            if "?" in message or len(message.split()) > 3:
                concern = message.strip()
                if concern not in state.profile.concerns:
                    state.profile.concerns.append(concern)
                    state.profile.concerns[:] = state.profile.concerns[-4:]
        state.turns.append(ChatTurn(role="user", content=message or str(structured)))

        analysis = analyse(state.profile, message, retriever=self.retriever)
        questions = self.choose_questions(state, message, analysis) if ask_questions else []
        analysis.questions = questions
        return AgentResult(analysis=analysis, questions=questions, changes=changes)

    def profile(self, session_id: str) -> SiteProfile:
        return self.store.get(session_id).profile

    def reset(self, session_id: str) -> None:
        self.store.reset(session_id)
