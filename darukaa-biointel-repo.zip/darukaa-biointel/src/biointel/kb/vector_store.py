"""A small, persistent vector store plus a BM25 lexical index.

Deliberately dependency-light: an in-process numpy matrix with cosine similarity,
persisted to ``.index/``. For a corpus of this size (tens to low thousands of cards)
an exact search beats an approximate one on both latency and honesty. A
``ChromaVectorStore`` adapter is provided for drop-in replacement at larger scale;
the retriever depends only on the ``search`` signature.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from pathlib import Path

import numpy as np

from ..config import INDEX_DIR
from .embeddings import Encoder, get_encoder

_WORD = re.compile(r"[a-z0-9]+")

_STOP = {
    "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with", "is", "are",
    "be", "by", "that", "this", "it", "as", "at", "from", "than", "which", "can", "my",
    "i", "we", "you", "not", "but", "has", "have", "do", "does", "how", "what", "why",
}


def tokenize(text: str) -> list[str]:
    return [t for t in _WORD.findall(text.lower()) if t not in _STOP and len(t) > 1]


class BM25:
    """Standard Okapi BM25. Lexical recall matters here because scientific queries
    carry exact terms ('sodic', 'Faidherbia', 'neonicotinoid') that a small dense
    model routinely smooths away."""

    def __init__(self, docs: list[list[str]], k1: float = 1.5, b: float = 0.75) -> None:
        self.k1, self.b = k1, b
        self.docs = docs
        self.N = len(docs)
        self.avgdl = sum(len(d) for d in docs) / max(1, self.N)
        self.tf = [Counter(d) for d in docs]
        df: Counter[str] = Counter()
        for d in docs:
            df.update(set(d))
        self.idf = {
            t: math.log(1 + (self.N - n + 0.5) / (n + 0.5)) for t, n in df.items()
        }

    def score(self, query: str) -> np.ndarray:
        q = tokenize(query)
        scores = np.zeros(self.N, dtype=np.float32)
        for i, tf in enumerate(self.tf):
            dl = len(self.docs[i]) or 1
            s = 0.0
            for term in q:
                f = tf.get(term, 0)
                if not f:
                    continue
                idf = self.idf.get(term, 0.0)
                s += idf * (f * (self.k1 + 1)) / (
                    f + self.k1 * (1 - self.b + self.b * dl / self.avgdl)
                )
            scores[i] = s
        return scores


class VectorStore:
    def __init__(self, encoder: Encoder | None = None) -> None:
        self.encoder = encoder or get_encoder()
        self.ids: list[str] = []
        self.matrix: np.ndarray | None = None
        self.bm25: BM25 | None = None
        self._texts: list[str] = []

    def build(self, ids: list[str], texts: list[str]) -> None:
        self.ids = list(ids)
        self._texts = list(texts)
        self.matrix = self.encoder.encode(texts)
        self.bm25 = BM25([tokenize(t) for t in texts])

    # --- persistence -------------------------------------------------
    def save(self, path: Path | None = None) -> Path:
        path = path or INDEX_DIR
        path.mkdir(parents=True, exist_ok=True)
        np.save(path / "vectors.npy", self.matrix)
        (path / "meta.json").write_text(
            json.dumps({"ids": self.ids, "encoder": self.encoder.name, "texts": self._texts})
        )
        return path

    def load(self, path: Path | None = None) -> bool:
        path = path or INDEX_DIR
        if not (path / "vectors.npy").exists():
            return False
        meta = json.loads((path / "meta.json").read_text())
        if meta.get("encoder") != self.encoder.name:
            return False  # stale index built with a different encoder
        self.ids = meta["ids"]
        self._texts = meta["texts"]
        self.matrix = np.load(path / "vectors.npy")
        self.bm25 = BM25([tokenize(t) for t in self._texts])
        return True

    # --- search ------------------------------------------------------
    def dense_search(self, query: str, k: int) -> list[tuple[str, float]]:
        assert self.matrix is not None, "index not built"
        q = self.encoder.encode([query])[0]
        sims = self.matrix @ q
        order = np.argsort(-sims)[:k]
        return [(self.ids[i], float(sims[i])) for i in order]

    def lexical_search(self, query: str, k: int) -> list[tuple[str, float]]:
        assert self.bm25 is not None, "index not built"
        scores = self.bm25.score(query)
        order = np.argsort(-scores)[:k]
        return [(self.ids[i], float(scores[i])) for i in order if scores[i] > 0]


class ChromaVectorStore(VectorStore):  # pragma: no cover - optional scale-out path
    """Adapter kept deliberately thin. Swap in by setting BIOINTEL_VECTOR_BACKEND=chroma
    once the corpus outgrows exact search; the retriever contract is unchanged."""

    def build(self, ids: list[str], texts: list[str]) -> None:
        import chromadb

        client = chromadb.PersistentClient(path=str(INDEX_DIR / "chroma"))
        self._col = client.get_or_create_collection("biointel")
        self._col.upsert(ids=ids, documents=texts,
                         embeddings=self.encoder.encode(texts).tolist())
        self.ids, self._texts = list(ids), list(texts)
        self.bm25 = BM25([tokenize(t) for t in texts])

    def dense_search(self, query: str, k: int) -> list[tuple[str, float]]:
        res = self._col.query(query_embeddings=self.encoder.encode([query]).tolist(), n_results=k)
        return [(i, 1.0 - d) for i, d in zip(res["ids"][0], res["distances"][0], strict=False)]
