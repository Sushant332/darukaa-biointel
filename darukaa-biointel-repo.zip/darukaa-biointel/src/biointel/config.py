from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = Path(os.getenv("BIOINTEL_DATA_DIR", ROOT / "data"))
KB_DIR = DATA_DIR / "knowledge"
ONTOLOGY_PATH = DATA_DIR / "ontology" / "metrics.yaml"
INDEX_DIR = Path(os.getenv("BIOINTEL_INDEX_DIR", ROOT / ".index"))

# Dense encoder. Falls back to a deterministic hashed n-gram encoder when
# sentence-transformers is not installed, so the pipeline never hard-fails.
EMBED_MODEL = os.getenv("BIOINTEL_EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
USE_ST = os.getenv("BIOINTEL_USE_ST", "auto")  # auto | yes | no

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
LLM_MODEL = os.getenv("BIOINTEL_LLM_MODEL", "claude-sonnet-4-6")

TOP_K_DENSE = int(os.getenv("BIOINTEL_TOP_K_DENSE", "12"))
TOP_K_LEXICAL = int(os.getenv("BIOINTEL_TOP_K_LEXICAL", "12"))
TOP_K_FINAL = int(os.getenv("BIOINTEL_TOP_K_FINAL", "8"))
MAX_RECOMMENDATIONS = int(os.getenv("BIOINTEL_MAX_RECS", "5"))
