"""Golden-case evaluation.

Scores the engine against hand-specified expectations per case:

* ``must_include`` — cards a competent environmental scientist would raise here.
* ``must_exclude`` — cards that are actively wrong for this site (the harder test).
* ``must_diagnose`` — the binding constraints that should be identified.
* ``min_domains``  — the multi-metric floor: how many distinct domains the plan spans.

Run: ``PYTHONPATH=src python eval/run_eval.py``
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from biointel.kb.retriever import Retriever
from biointel.reasoning.engine import analyse
from biointel.reasoning.ontology import get_ontology
from biointel.schemas import SiteProfile

CASES = json.loads((Path(__file__).parent / "golden_cases.json").read_text())


def main() -> int:
    retriever = Retriever()
    onto = get_ontology()
    total = 0.0
    rows = []
    for case in CASES:
        profile = SiteProfile.model_validate(case["profile"])
        analysis = analyse(profile, case.get("question", ""), retriever=retriever)
        ids = {r.card_id for r in analysis.recommendations}
        diag = set(analysis.diagnosis.limiting_factors)
        domains = {onto.domain(d.metric) for r in analysis.recommendations for d in r.metric_deltas}

        inc = set(case.get("must_include", []))
        exc = set(case.get("must_exclude", []))
        dia = set(case.get("must_diagnose", []))

        s_inc = len(inc & ids) / len(inc) if inc else 1.0
        s_exc = 1.0 - (len(exc & ids) / len(exc) if exc else 0.0)
        s_dia = len(dia & diag) / len(dia) if dia else 1.0
        s_dom = min(1.0, len(domains) / case.get("min_domains", 3))
        s_evd = sum(1 for r in analysis.recommendations if r.sources) / max(1, len(ids))
        score = 0.3 * s_inc + 0.25 * s_exc + 0.2 * s_dia + 0.15 * s_dom + 0.1 * s_evd
        total += score
        rows.append((case["name"], score, s_inc, s_exc, s_dia, s_dom, sorted(ids)))

    print(f"{'case':38} {'score':>6} {'incl':>5} {'excl':>5} {'diag':>5} {'dom':>5}")
    print("-" * 74)
    for name, score, a, b, c, d, ids in rows:
        print(f"{name[:38]:38} {score:6.2f} {a:5.2f} {b:5.2f} {c:5.2f} {d:5.2f}")
        print(f"    -> {', '.join(ids)}")
    mean = total / len(rows)
    print("-" * 74)
    print(f"{'MEAN':38} {mean:6.2f}")
    return 0 if mean >= 0.8 else 1


if __name__ == "__main__":
    raise SystemExit(main())
