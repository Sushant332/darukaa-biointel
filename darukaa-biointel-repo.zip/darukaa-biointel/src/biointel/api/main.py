"""HTTP surface.

Endpoints are deliberately transparent: ``/chat`` returns not only the reply but the
retrieval hits (including the cards that were *excluded* and why) and the full analysis
object, so the knowledge pipeline can be inspected rather than trusted.
"""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ..conversation.agent import BioIntelAgent
from ..kb.loader import load_cards
from ..llm.client import narrate, render_markdown
from ..schemas import Analysis, ChatRequest, ChatResponse, SiteProfile

app = FastAPI(
    title="Darukaa BioIntel",
    version="0.1.0",
    description="Evidence-grounded biodiversity advisory engine: retrieval + causal reasoning.",
)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

agent = BioIntelAgent()


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "cards": len(load_cards()),
        "encoder": agent.retriever.encoder_name,
    }


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    if not req.message and not req.structured:
        raise HTTPException(400, "provide message or structured")
    result = agent.handle(req.session_id, req.message, req.structured)
    reply = narrate(result.analysis, req.message)
    return ChatResponse(
        session_id=req.session_id,
        reply=reply,
        analysis=result.analysis,
        profile=agent.profile(req.session_id),
        asked=result.questions,
    )


class AnalyzeRequest(BaseModel):
    profile: SiteProfile
    question: str = ""
    render: bool = False


@app.post("/analyze")
def analyze(req: AnalyzeRequest) -> dict[str, Any]:
    from ..reasoning.engine import analyse

    analysis: Analysis = analyse(req.profile, req.question, retriever=agent.retriever)
    out: dict[str, Any] = {"analysis": analysis.model_dump(mode="json")}
    if req.render:
        out["markdown"] = render_markdown(analysis)
    return out


class SearchRequest(BaseModel):
    query: str
    profile: SiteProfile | None = None
    k: int = 8


@app.post("/kb/search")
def kb_search(req: SearchRequest) -> dict[str, Any]:
    hits = agent.retriever.search(req.query, req.profile, k=req.k)
    cards = {c.id: c for c in load_cards()}
    return {
        "encoder": agent.retriever.encoder_name,
        "hits": [
            {
                **h.model_dump(),
                "title": cards[h.card_id].title,
                "kind": cards[h.card_id].kind,
            }
            for h in hits
        ],
    }


@app.get("/kb/cards")
def kb_cards() -> dict[str, Any]:
    return {"cards": [c.model_dump(mode="json") for c in load_cards()]}


@app.get("/session/{session_id}")
def get_session(session_id: str) -> dict[str, Any]:
    state = agent.store.get(session_id)
    return {
        "profile": state.profile.model_dump(mode="json"),
        "journal": state.journal,
        "asked_slots": sorted(state.asked_slots),
        "turns": [t.model_dump() for t in state.turns],
    }


@app.delete("/session/{session_id}")
def reset_session(session_id: str) -> dict[str, str]:
    agent.reset(session_id)
    return {"status": "reset"}
