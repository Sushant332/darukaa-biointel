"""Interactive terminal client.

    python -m biointel.cli                      # conversational mode
    python -m biointel.cli --json site.json     # one-shot structured analysis
    python -m biointel.cli --search "sodic soil" # inspect the retrieval layer
"""
from __future__ import annotations

import argparse
import json
import sys

from .conversation.agent import BioIntelAgent
from .kb.loader import card_index
from .llm.client import render_markdown
from .reasoning.engine import analyse
from .schemas import SiteProfile


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="biointel")
    ap.add_argument("--json", help="path to a structured site profile JSON file")
    ap.add_argument("--search", help="run a raw knowledge-base query and show the pipeline")
    ap.add_argument("--question", default="", help="free-text question to accompany --json")
    args = ap.parse_args(argv)

    agent = BioIntelAgent()

    if args.search:
        cards = card_index()
        hits = agent.retriever.search(args.search, k=8)
        print(f"encoder: {agent.retriever.encoder_name}\n")
        for h in hits:
            mark = "EXCLUDED" if h.excluded else f"score={h.score:.5f}"
            print(f"[{mark}] {h.card_id} — {cards[h.card_id].title}")
            print(f"    dense_rank={h.dense_rank} lexical_rank={h.lexical_rank} fit={h.fit_score}")
            if h.exclusion_reason:
                print(f"    reason: {h.exclusion_reason}")
        return 0

    if args.json:
        with open(args.json, encoding="utf-8") as fh:
            payload = json.load(fh)
        profile = SiteProfile.model_validate(payload)
        print(render_markdown(analyse(profile, args.question, retriever=agent.retriever)))
        return 0

    print("Darukaa BioIntel — describe your land, or paste JSON. Ctrl-D to exit.\n")
    session = "cli"
    while True:
        try:
            line = input("you > ").strip()
        except EOFError:
            print()
            return 0
        if not line:
            continue
        structured = None
        if line.startswith("{"):
            try:
                structured = json.loads(line)
                line = ""
            except json.JSONDecodeError:
                pass
        result = agent.handle(session, line, structured)
        if result.changes:
            print(f"\n[memory updated: {'; '.join(result.changes)}]")
        print("\n" + render_markdown(result.analysis) + "\n")


if __name__ == "__main__":
    sys.exit(main())
