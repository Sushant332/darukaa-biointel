"""The reasoning engine: from a site profile to a sequenced, evidence-backed plan.

Pipeline inside ``analyse``:

    profile -> diagnose -> query expansion -> hybrid retrieval -> candidate gating
            -> leverage scoring -> causal propagation -> interaction & conflict detection
            -> sequencing -> confidence assignment

Nothing here calls a language model. The language layer only renders what this
produces, which is why the recommendations stay stable, auditable and testable.
"""
from __future__ import annotations

from ..config import MAX_RECOMMENDATIONS, TOP_K_FINAL
from ..kb.loader import card_index
from ..kb.retriever import Retriever
from ..schemas import (
    Analysis,
    Diagnosis,
    EvidenceCard,
    MetricDelta,
    Recommendation,
    RetrievalHit,
    SiteProfile,
)
from .diagnostics import diagnose
from .ontology import get_ontology

# Which metrics each diagnosed constraint actually needs moved.
LIMITING_TARGETS: dict[str, set[str]] = {
    "carbon_depletion": {"soil_organic_carbon", "soil_microbial_diversity", "soil_fauna_abundance"},
    "acidity_aluminium": {"soil_ph", "nitrogen_balance"},
    "sodicity_alkalinity": {"soil_ph", "soil_moisture"},
    "water_limitation": {"soil_moisture", "groundwater_recharge", "erosion_rate", "water_use"},
    "aquifer_overdraft": {"water_use", "groundwater_recharge"},
    "species_pool_depletion": {"habitat_connectivity", "species_richness", "vegetation_cover"},
    "connectivity_limitation": {"habitat_connectivity", "species_richness", "pollinator_abundance"},
    "structural_simplicity": {
        "species_richness", "habitat_connectivity", "vegetation_cover",
        "pollinator_abundance", "natural_pest_control",
    },
    "surface_degradation": {"soil_moisture", "vegetation_cover", "erosion_rate"},
}

# Actions that are a *necessary condition* for relieving a given constraint. Other
# measures under-deliver until these are in place, so they are given a leverage floor
# rather than being allowed to lose to a broader, cheaper practice on aggregate score.
# This encodes an ordering judgement that the scoring function alone cannot express.
CONSTRAINT_KEYSTONES: dict[str, set[str]] = {
    "species_pool_depletion": {"INT-CORRIDOR-PATCH", "INT-NATIVE-REMNANT-PROTECT"},
    "acidity_aluminium": {"INT-LIME-ACID"},
    "sodicity_alkalinity": {"INT-GYPSUM-SODIC"},
    "aquifer_overdraft": {"INT-MILLET-SHIFT"},
    "surface_degradation": {"INT-ZAI-DEMILUNE", "INT-FMNR"},
}

COST_WEIGHT = {"very_low": 1.0, "low": 0.85, "medium": 0.6, "high": 0.4, None: 0.6}
HORIZON_ORDER = {"short": 0, "medium": 1, "long": 2}


def build_queries(profile: SiteProfile, user_text: str, diagnosis: Diagnosis) -> list[str]:
    """Expand a site into the several sub-questions it actually implies.

    A single blended query retrieves the average of the site's problems. Fanning out
    over the diagnosed constraints retrieves the specific evidence for each of them.
    """
    queries: list[str] = []
    if user_text.strip():
        queries.append(user_text.strip())

    bits = []
    if profile.land_use:
        bits.append(profile.land_use.value.replace("_", " "))
    if profile.climate_zone:
        bits.append(profile.climate_zone.value.replace("_", " "))
    if profile.crop:
        bits.append(profile.crop)
    if bits:
        queries.append(" ".join(bits) + " biodiversity restoration options")

    constraint_queries = {
        "carbon_depletion": "restore soil organic carbon on depleted cropland cover crops residue",
        "acidity_aluminium": "correct acidic soil aluminium toxicity liming nodulation",
        "sodicity_alkalinity": "sodic alkaline soil gypsum infiltration reclamation",
        "water_limitation": "water harvesting infiltration soil moisture retention dryland",
        "aquifer_overdraft": "reduce groundwater abstraction crop water use millets",
        "species_pool_depletion": "habitat fragmentation corridor source patch connectivity",
        "connectivity_limitation": "hedgerow field margin corridor connectivity pollinators",
        "structural_simplicity": "structural complexity trees on farmland crop diversification birds",
        "surface_degradation": "degraded crusted land rehabilitation planting pits regeneration",
    }
    for lf in diagnosis.limiting_factors:
        if lf in constraint_queries:
            queries.append(constraint_queries[lf])

    for pressure in profile.pressures:
        queries.append(pressure.value.replace("_", " ") + " impact mitigation")
    for concern in profile.concerns[:2]:
        queries.append(concern)
    if not queries:
        queries.append("biodiversity improvement land management")
    return queries


def _evidence_strength(card: EvidenceCard) -> float:
    base = (
        sum(e.confidence for e in card.effects) / len(card.effects)
        if card.effects
        else 0.55
    )
    source_bonus = min(0.12, 0.04 * len(card.sources))
    return min(0.97, base + source_bonus)


def _leverage(card: EvidenceCard, hit: RetrievalHit, diagnosis: Diagnosis) -> tuple[float, list[str]]:
    onto = get_ontology()
    targets: set[str] = set()
    for lf in diagnosis.limiting_factors:
        targets |= LIMITING_TARGETS.get(lf, set())

    def _is_improvement(metric: str, direction: str) -> bool:
        higher_better = onto.metrics.get(metric, {}).get("higher_is_better")
        if higher_better is None:          # e.g. pH, where "better" means "toward optimum"
            return True
        return (direction == "up") if higher_better else (direction == "down")

    touched = {e.metric for e in card.effects if _is_improvement(e.metric, e.direction)}
    aligned = touched & targets

    # Alignment is weighted by constraint *severity*, so a practice that fixes the site's
    # worst problem outranks one that nibbles at three mild ones. Without this weighting a
    # broad, cheap, well-evidenced practice displaces the single action the site actually
    # needs - the failure mode that produces plausible but ineffective advice.
    if diagnosis.limiting_factors:
        num = den = 0.0
        for lf in diagnosis.limiting_factors:
            tg = LIMITING_TARGETS.get(lf, set())
            if not tg:
                continue
            w = diagnosis.severity.get(lf, 0.5)
            num += w * len(touched & tg) / len(tg)
            den += w
        alignment = num / den if den else 0.3
        primary = diagnosis.limiting_factors[0]
        ptg = LIMITING_TARGETS.get(primary, set())
        primary_alignment = len(touched & ptg) / len(ptg) if ptg else 0.3
    else:
        alignment = primary_alignment = 0.3
        primary = None

    domains = {onto.domain(e.metric) for e in card.effects}
    breadth = min(1.0, len(domains) / 3.0)

    strength = _evidence_strength(card)
    cost = COST_WEIGHT.get(card.cost, 0.6)

    score = (
        0.28 * alignment
        + 0.20 * primary_alignment
        + 0.18 * breadth
        + 0.18 * strength
        + 0.08 * cost
        + 0.08 * min(1.0, hit.fit_score)
    )
    for lf in diagnosis.limiting_factors:
        if card.id in CONSTRAINT_KEYSTONES.get(lf, set()):
            floor = 0.62 + 0.30 * diagnosis.severity.get(lf, 0.5)
            score = max(score, floor)
            break

    basis = []
    keystone_for = [lf for lf in diagnosis.limiting_factors
                    if card.id in CONSTRAINT_KEYSTONES.get(lf, set())]
    if keystone_for:
        basis.append(
            "necessary condition for relieving "
            + ", ".join(lf.replace("_", " ") for lf in keystone_for)
            + " - other measures under-deliver until this is in place"
        )
    if aligned:
        basis.append(
            "addresses the diagnosed constraint directly via "
            + ", ".join(sorted(onto.label(m) for m in aligned))
        )
    if primary and primary_alignment > 0.3:
        basis.append(f"targets the primary constraint ({primary.replace('_', ' ')})")
    if len(domains) >= 3:
        basis.append(f"acts across {len(domains)} domains ({', '.join(sorted(domains))})")
    basis.append(f"mean effect confidence {strength:.2f} across {len(card.sources)} cited sources")
    return round(score, 4), basis


def _deltas_for(card: EvidenceCard) -> list[MetricDelta]:
    onto = get_ontology()
    direct = [
        MetricDelta(
            metric=e.metric,
            direction=e.direction,
            magnitude=e.magnitude,
            horizon=e.horizon,
            confidence=e.confidence,
            pathway="direct",
            why=None,
        )
        for e in card.effects
    ]
    # Seeds are expressed as a change in the metric's VALUE (+1 rises, -1 falls),
    # not as "good" or "bad". The graph edges carry the same convention, so signs
    # compose correctly along a path: a practice that lowers erosion propagates a
    # value-decrease along a negative edge and therefore raises water quality.
    seeds = {e.metric: (1 if e.direction == "up" else -1) for e in card.effects}

    propagated = onto.propagate(seeds) if seeds else {}
    out = list(direct)
    for metric, info in sorted(propagated.items(), key=lambda kv: -kv[1]["weight"])[:6]:
        direction = "up" if info["sign"] > 0 else "down"
        out.append(
            MetricDelta(
                metric=metric,
                direction=direction,
                magnitude=f"indirect, coupling strength {info['weight']:.2f}",
                horizon=onto.horizon_for_lag(info["lag"]),
                confidence=round(min(0.8, 0.45 + 0.4 * info["weight"]), 2),
                pathway="propagated",
                via=info["path"][:-1],
                why=info["why"][-1] if info["why"] else None,
            )
        )
    return out


def _confidence(card: EvidenceCard, hit: RetrievalHit, profile: SiteProfile) -> tuple[float, list[str]]:
    basis: list[str] = []
    strength = _evidence_strength(card)
    fit = hit.fit_score
    known = len(profile.known_slots())
    completeness = min(1.0, known / 9.0)
    conf = 0.5 * strength + 0.3 * fit + 0.2 * completeness
    basis.append(f"evidence base: {len(card.sources)} sources, mean effect confidence {strength:.2f}")
    if fit >= 0.8:
        basis.append("site conditions fall inside the evidence window for this practice")
    elif fit >= 0.4:
        basis.append("site partially matches the conditions in the underlying studies")
    else:
        basis.append("site match is weak or unverified - treat as a hypothesis to test")
    if completeness < 0.5:
        basis.append("confidence is capped by incomplete site data")
    return round(min(0.95, conf), 2), basis


def _stage(card: EvidenceCard, diagnosis: Diagnosis) -> int:
    if card.kind == "caution":
        return 1
    if card.id == "INT-NATIVE-REMNANT-PROTECT":
        return 1
    if card.prerequisites and any("tenure" in p.lower() or "grazing" in p.lower()
                                 for p in card.prerequisites):
        return 1
    horizons = [HORIZON_ORDER.get(e.horizon, 1) for e in card.effects] or [1]
    median = sorted(horizons)[len(horizons) // 2]
    if card.cost in ("very_low", "low") and median == 0:
        return 1
    return 2 if median <= 1 else 3


def _monitoring(card: EvidenceCard) -> list[str]:
    onto = get_ontology()
    out = []
    for e in card.effects[:3]:
        label = onto.label(e.metric)
        unit = onto.metrics.get(e.metric, {}).get("unit", "")
        cadence = {"short": "each season", "medium": "annually", "long": "every 3 years"}[e.horizon]
        out.append(f"{label} ({unit}) - baseline now, then {cadence}")
    return out


def analyse(
    profile: SiteProfile,
    user_text: str = "",
    retriever: Retriever | None = None,
    max_recs: int = MAX_RECOMMENDATIONS,
) -> Analysis:
    retriever = retriever or Retriever()
    cards = card_index()
    diagnosis = diagnose(profile)
    queries = build_queries(profile, user_text, diagnosis)
    hits = retriever.multi_query(queries, profile, k=TOP_K_FINAL)

    scored: list[tuple[float, RetrievalHit, EvidenceCard, list[str]]] = []
    for hit in hits:
        if hit.excluded:
            continue
        card = cards[hit.card_id]
        if card.kind in ("mechanism", "context"):
            continue  # supporting evidence, not an action
        lev, basis = _leverage(card, hit, diagnosis)
        scored.append((lev, hit, card, basis))
    scored.sort(key=lambda t: -t[0])

    recs: list[Recommendation] = []
    covered_metrics: set[str] = set()
    for lev, hit, card, basis in scored:
        if len(recs) >= max_recs:
            break
        new_metrics = {e.metric for e in card.effects} - covered_metrics
        # Diversity guard: a fifth carbon practice adds less than a first water practice.
        # It yields, though, to a card whose leverage is close to the best on the list -
        # a high-leverage action is not dropped merely for overlapping with one already
        # chosen.
        if recs and not new_metrics and lev < 0.88 * recs[0].leverage_score:
            continue
        conf, conf_basis = _confidence(card, hit, profile)
        deltas = _deltas_for(card)
        horizons = [HORIZON_ORDER.get(d.horizon, 1) for d in deltas if d.pathway == "direct"] or [1]
        horizon = ["short", "medium", "long"][sorted(horizons)[len(horizons) // 2]]
        recs.append(
            Recommendation(
                card_id=card.id,
                title=card.title,
                action=card.summary.strip(),
                rationale=card.mechanism.strip(),
                metric_deltas=deltas,
                horizon=horizon,
                confidence=conf,
                confidence_basis=conf_basis + basis,
                prerequisites=card.prerequisites,
                tradeoffs=card.tradeoffs,
                sources=card.sources,
                leverage_score=lev,
                sequence_stage=_stage(card, diagnosis),
                monitoring=_monitoring(card),
            )
        )
        covered_metrics |= {e.metric for e in card.effects}

    recs.sort(key=lambda r: (r.sequence_stage, -r.leverage_score))

    interactions, conflicts = _interactions(recs, cards)
    coverage = len(covered_metrics) / max(1, len(get_ontology().metrics))

    return Analysis(
        profile=profile,
        diagnosis=diagnosis,
        retrieval=hits,
        recommendations=recs,
        interactions=interactions,
        conflicts=conflicts,
        coverage=round(coverage, 3),
    )


def _interactions(recs: list[Recommendation], cards: dict[str, EvidenceCard]) -> tuple[list[str], list[str]]:
    onto = get_ontology()
    chosen = {r.card_id for r in recs}
    interactions: list[str] = []
    conflicts: list[str] = []

    for r in recs:
        card = cards[r.card_id]
        for syn in card.synergies:
            if syn in chosen and syn > r.card_id:
                interactions.append(
                    f"{card.title} and {cards[syn].title} reinforce each other; "
                    "implemented together they deliver more than the sum of the two alone."
                )
        for con in card.conflicts:
            if con in chosen:
                conflicts.append(
                    f"{card.title} works against {cards[con].title}. Choose one deliberately "
                    "rather than adopting both."
                )
    # Metric-level antagonism: one recommendation pushes a metric up, another pushes it down.
    direction: dict[str, list[tuple[str, str]]] = {}
    for r in recs:
        for d in r.metric_deltas:
            if d.pathway != "direct":
                continue
            direction.setdefault(d.metric, []).append((d.direction, r.title))
    for metric, entries in direction.items():
        dirs = {e[0] for e in entries}
        if len(dirs) > 1:
            titles = ", ".join(sorted({t for _, t in entries}))
            conflicts.append(
                f"{onto.label(metric)} is pushed in opposite directions by: {titles}. "
                "Net effect depends on design and must be monitored, not assumed."
            )
    for pair in onto.antagonisms:
        a, b = pair["a"], pair["b"]
        if a in direction and b in direction:
            interactions.append(f"Known tension - {pair['note']}")

    return list(dict.fromkeys(interactions)), list(dict.fromkeys(conflicts))
