"""Darukaa BioIntel — an evidence-grounded biodiversity advisory engine."""
__version__ = "0.1.0"
