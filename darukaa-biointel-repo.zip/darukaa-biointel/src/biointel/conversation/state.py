"""Conversation state: incremental slot filling with persistent session memory.

The profile is the memory. Free text and structured JSON both write into the same
``SiteProfile``, so a user can type "SOC is 0.3%" in turn one, paste a JSON payload in
turn three, and correct "actually it's semi-arid" in turn five, and the engine sees one
coherent site. Every write is journalled so the assistant can say *where* a value came
from, and so a correction is visibly a correction rather than a silent overwrite.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from ..schemas import ChatTurn, ClimateZone, LandUse, Pressure, SiteProfile

NUM = r"(-?\d+(?:\.\d+)?)"

LAND_USE_HINTS = {
    LandUse.paddy: ["paddy", "rice field", "rice cultivation", "transplanted rice"],
    LandUse.orchard: ["orchard", "mango", "citrus", "apple", "plantation crop", "coffee", "tea estate"],
    LandUse.pasture: ["pasture", "grazing land", "rangeland", "grassland", "meadow"],
    LandUse.forest: ["forest", "woodland", "reserve forest"],
    LandUse.agroforestry: ["agroforestry", "silvopast", "alley crop"],
    LandUse.wetland: ["wetland", "marsh", "tank bed", "pond", "lake"],
    LandUse.degraded_land: ["degraded", "barren", "wasteland", "fallow land", "bare land", "mining spoil"],
    LandUse.village_commons: ["commons", "panchayat land", "gochar", "village land"],
    LandUse.homestead: ["homestead", "kitchen garden", "backyard"],
    LandUse.cropland: ["cropland", "farm", "field", "wheat", "maize", "cotton", "soybean", "millet", "farmland"],
}

# Order matters: the more specific compounds are tested first, because "semi-arid"
# contains "arid" and "sub-humid" contains "humid". Getting this wrong silently
# reclassifies the site and changes every downstream recommendation.
CLIMATE_HINTS = {
    ClimateZone.semi_arid: ["semi-arid", "semi arid", "semiarid", "dryland", "drought-prone", "drought prone"],
    ClimateZone.sub_humid: ["sub-humid", "sub humid", "subhumid"],
    ClimateZone.arid: ["arid", "desert", "very dry", "hyper-arid"],
    ClimateZone.humid: ["humid", "high rainfall", "wet zone", "monsoonal wet", "heavy monsoon"],
    ClimateZone.temperate: ["temperate", "hill station", "cold winter"],
}

PRESSURE_HINTS = {
    Pressure.residue_burning: ["burn the stubble", "stubble burning", "residue burning", "burn residue", "we burn"],
    Pressure.heavy_pesticide: ["spray every", "heavy pesticide", "lot of pesticide", "calendar spray", "pesticide use is high", "spraying weekly"],
    Pressure.effluent_inflow: ["effluent", "sewage", "factory discharge", "industrial waste"],
    Pressure.open_grazing: ["open grazing", "free grazing", "cattle roam", "uncontrolled grazing"],
    Pressure.dust_deposition: ["quarry", "brick kiln", "cement plant", "dust from", "highway dust"],
    Pressure.groundwater_depletion: ["borewell is drying", "borewell that keeps drying", "keeps drying up", "runs dry", "water table", "groundwater dropping", "well has dried", "aquifer depleting", "deepening the borewell", "drilling deeper", "bore well dry"],
    Pressure.recent_clearing: ["cleared", "cut down", "removed the trees", "converted the scrub", "felled"],
}


def _find(pattern: str, text: str) -> float | None:
    m = re.search(pattern, text, re.IGNORECASE)
    return float(m.group(1)) if m else None


def extract_slots(text: str) -> dict[str, Any]:
    """Pull structured values out of ordinary sentences.

    Deliberately conservative: an ambiguous number is left alone rather than guessed,
    because a wrong pH silently changes the entire recommendation set.
    """
    out: dict[str, Any] = {}
    t = " " + text.lower() + " "

    soc = (
        _find(rf"(?:soil )?organic carbon[^0-9%]{{0,20}}{NUM}\s*%", t)
        or _find(rf"\bsoc\b[^0-9%]{{0,20}}{NUM}\s*%", t)
        or _find(rf"{NUM}\s*%\s*(?:soil )?organic carbon", t)
    )
    if soc is not None:
        out["soc_pct"] = soc

    ph = _find(rf"\bph\b(?:\s*(?:is|of|=|:|at))?\s*{NUM}", t)
    if ph is not None and 2.0 <= ph <= 12.0:
        out["ph"] = ph

    rain = (
        _find(rf"rainfall[^0-9]{{0,25}}{NUM}\s*mm", t)
        or _find(rf"{NUM}\s*mm\s*(?:of\s*)?(?:annual\s*)?rain", t)
        or _find(rf"receives?\s*(?:about\s*)?{NUM}\s*mm", t)
    )
    if rain is not None:
        out["rainfall_mm"] = rain

    area = _find(rf"{NUM}\s*(?:ha\b|hectare)", t)
    if area is None:
        acres = _find(rf"{NUM}\s*acre", t)
        if acres is not None:
            area = round(acres * 0.4047, 2)
    if area is not None:
        out["area_ha"] = area

    slope = _find(rf"slope[^0-9]{{0,15}}{NUM}\s*%", t)
    if slope is not None:
        out["slope_pct"] = slope

    trees = _find(rf"{NUM}\s*trees?\s*(?:per|/)\s*(?:ha|hectare|acre)", t)
    if trees is not None:
        out["tree_density_per_ha"] = trees

    seminat = _find(rf"{NUM}\s*%[^.]{0,40}(?:natural|forest|scrub|habitat)", t)
    if seminat is not None:
        out["semi_natural_pct"] = seminat

    temp = _find(rf"{NUM}\s*(?:°|deg(?:rees)?\s*)c\b", t)
    if temp is not None:
        out["mean_temp_c"] = temp

    for zone, hints in CLIMATE_HINTS.items():
        if any(h in t for h in hints):
            out["climate_zone"] = zone
            break

    for use, hints in LAND_USE_HINTS.items():
        if any(h in t for h in hints):
            out["land_use"] = use
            break

    if "monoculture" in t or "mono-crop" in t or "only wheat" in t or "single crop" in t:
        out["cropping_pattern"] = "monoculture"
    elif "rotation" in t or "intercrop" in t or "mixed crop" in t:
        out["cropping_pattern"] = "mixed"

    for crop in ["wheat", "rice", "maize", "cotton", "sugarcane", "soybean", "millet",
                 "sorghum", "groundnut", "mustard", "chickpea", "banana", "mango", "coffee", "tea"]:
        if f" {crop}" in t:
            out["crop"] = crop
            break

    if "borewell" in t or "tube well" in t or "tubewell" in t:
        out["irrigation_source"] = "groundwater"
    elif "canal" in t:
        out["irrigation_source"] = "canal"
    elif "rainfed" in t or "rain-fed" in t or "no irrigation" in t:
        out["irrigation_source"] = "rainfed"

    if any(w in t for w in ["cattle", "goat", "livestock", "buffalo", "sheep", "dairy"]):
        out["livestock"] = True

    pressures = [p for p, hints in PRESSURE_HINTS.items() if any(h in t for h in hints)]
    if pressures:
        out["pressures"] = pressures

    # Geo-coordinates: "22.57, 88.36" or "lat 22.57 lon 88.36"
    geo = re.search(rf"(?:lat[^0-9-]{{0,6}})?{NUM}\s*[,/]\s*(?:lon[a-z]*[^0-9-]{{0,6}})?{NUM}", t)
    if geo:
        lat, lon = float(geo.group(1)), float(geo.group(2))
        if -90 <= lat <= 90 and -180 <= lon <= 180 and (abs(lat) > 0.5 or abs(lon) > 0.5):
            out["latitude"], out["longitude"] = lat, lon

    return out


@dataclass
class SessionState:
    session_id: str = "default"
    profile: SiteProfile = field(default_factory=SiteProfile)
    turns: list[ChatTurn] = field(default_factory=list)
    journal: list[dict[str, Any]] = field(default_factory=list)
    asked_slots: set[str] = field(default_factory=set)

    def apply(self, values: dict[str, Any], source: str) -> list[str]:
        """Write values into the profile, returning a list of human-readable changes."""
        changes: list[str] = []
        for key, value in values.items():
            if value is None or not hasattr(self.profile, key):
                continue
            current = getattr(self.profile, key)
            if key in ("pressures", "concerns", "notes", "species_observations"):
                merged = list(dict.fromkeys(list(current) + list(value)))
                if merged != list(current):
                    setattr(self.profile, key, merged)
                    changes.append(f"{key}: {merged}")
                continue
            if current is not None and current != value:
                changes.append(f"{key}: updated {current} -> {value}")
            elif current is None:
                changes.append(f"{key}: {value}")
            setattr(self.profile, key, value)
        if changes:
            self.journal.append({"source": source, "changes": changes})
        return changes

    def ingest_text(self, text: str) -> list[str]:
        return self.apply(extract_slots(text), "free text")

    def ingest_structured(self, payload: dict[str, Any]) -> list[str]:
        """Accept a JSON payload, coercing values through the declared field types.

        Coercion matters: a raw ``"orchard"`` string must become ``LandUse.orchard``
        before it reaches the engine, or the gating logic silently stops working.
        Unknown or uncoercible fields are reported back rather than dropped in silence.
        """
        from pydantic import TypeAdapter

        fields = type(self.profile).model_fields
        clean: dict[str, Any] = {}
        rejected: list[str] = []
        for key, value in payload.items():
            if key not in fields:
                rejected.append(key)
                continue
            try:
                clean[key] = TypeAdapter(fields[key].annotation).validate_python(value)
            except Exception:  # noqa: BLE001
                rejected.append(f"{key} (invalid value {value!r})")
        changes = self.apply(clean, "structured input")
        if rejected:
            changes.append(f"ignored unrecognised fields: {sorted(rejected)}")
        return changes


class SessionStore:
    """In-process session memory. Swap for Redis/Postgres by reimplementing get/save."""

    def __init__(self) -> None:
        self._sessions: dict[str, SessionState] = {}

    def get(self, session_id: str) -> SessionState:
        return self._sessions.setdefault(session_id, SessionState(session_id=session_id))

    def reset(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
