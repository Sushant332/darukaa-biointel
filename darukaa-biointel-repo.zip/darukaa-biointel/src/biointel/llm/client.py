"""Language layer.

Strict separation of duties: the engine decides, the language layer only phrases. The
model is handed the finished ``Analysis`` as JSON and is explicitly forbidden from
introducing any claim, number, source or recommendation that is not in it. When no API
key is present the deterministic renderer below produces the same content without a
model at all, which is also what the test-suite asserts against.
"""
from __future__ import annotations

import json
import os

from ..config import ANTHROPIC_API_KEY, LLM_MODEL
from ..reasoning.ontology import get_ontology
from ..schemas import Analysis

SYSTEM = """You are the language surface of an environmental analysis engine.

You will receive a JSON object produced by a deterministic reasoning engine: a site
diagnosis, a ranked set of recommendations, causal metric deltas, source citations,
detected interactions and conflicts, and any clarifying questions.

Rules, in order of priority:
1. Never introduce a fact, figure, mechanism, source or recommendation that is not in the
   JSON. If something is absent, it is absent. Do not fill gaps from your own knowledge.
2. Never drop a trade-off, prerequisite or conflict. These are the parts a user most needs.
3. Keep each recommendation's four parts visible: what to do, why it works, which metrics
   move (with time horizon), and the source.
4. Report confidence as given, and say plainly when it is capped by missing data.
5. Write as an environmental scientist briefing a land manager: direct, specific, no
   marketing language, no generic sustainability phrasing.
6. If clarifying questions are present, answer first with the provisional analysis, then
   ask them at the end, with the reason each one matters.
"""


def render_markdown(analysis: Analysis) -> str:
    """Deterministic rendering. No model involved; this is the reference output."""
    onto = get_ontology()
    p = analysis.profile
    lines: list[str] = []

    known = sorted(p.known_slots())
    lines.append("## Site read")
    if known:
        desc = []
        if p.land_use:
            desc.append(f"{p.land_use.value.replace('_', ' ')}")
        if p.crop:
            desc.append(f"under {p.crop}")
        if p.climate_zone:
            desc.append(f"in a {p.climate_zone.value.replace('_', ' ')} zone")
        if p.rainfall_mm:
            desc.append(f"receiving ~{p.rainfall_mm:.0f} mm/yr")
        if p.area_ha:
            desc.append(f"over {p.area_ha} ha")
        lines.append(" ".join(desc) if desc else "Site details captured.")
    else:
        lines.append("No site parameters captured yet.")

    d = analysis.diagnosis
    if d.stop_conditions:
        lines.append("\n## Stop conditions — deal with these first")
        for s in d.stop_conditions:
            lines.append(f"- {s}")
    if d.findings:
        lines.append("\n## Diagnosis")
        for f in d.findings:
            lines.append(f"- {f}")
    if d.limiting_factors:
        lines.append(
            "\nBinding constraints identified: "
            + ", ".join(lf.replace("_", " ") for lf in d.limiting_factors)
            + "."
        )

    if analysis.recommendations:
        lines.append("\n## Recommendations")
        stage_names = {1: "Stage 1 — enabling and immediate",
                       2: "Stage 2 — build over 1–3 years",
                       3: "Stage 3 — decadal investment"}
        current_stage = None
        for i, r in enumerate(analysis.recommendations, 1):
            if r.sequence_stage != current_stage:
                current_stage = r.sequence_stage
                lines.append(f"\n**{stage_names.get(current_stage, 'Stage')}**")
            lines.append(f"\n### {i}. {r.title}")
            lines.append(f"**What to do.** {r.action}")
            lines.append(f"\n**Why it works.** {r.rationale}")
            direct = [m for m in r.metric_deltas if m.pathway == "direct"]
            prop = [m for m in r.metric_deltas if m.pathway == "propagated"]
            if direct:
                lines.append("\n**Metrics that move (direct):**")
                for m in direct:
                    arrow = "↑" if m.direction == "up" else "↓"
                    mag = f" — {m.magnitude}" if m.magnitude else ""
                    lines.append(f"- {arrow} {onto.label(m.metric)}{mag} *({m.horizon} term)*")
            if prop:
                lines.append("\n**Knock-on effects the engine traced through the metric graph:**")
                for m in prop:
                    arrow = "↑" if m.direction == "up" else "↓"
                    via = " → ".join(onto.label(v) for v in m.via)
                    lines.append(f"- {arrow} {onto.label(m.metric)} via {via} *({m.horizon} term)* — {m.why}")
            lines.append(f"\n**Time horizon:** {r.horizon}  |  **Confidence:** {r.confidence:.2f}")
            if r.confidence_basis:
                lines.append(f"  \n*Confidence basis:* {'; '.join(r.confidence_basis)}")
            if r.prerequisites:
                lines.append("\n**Preconditions:** " + " ".join(f"{x}" for x in r.prerequisites))
            if r.tradeoffs:
                lines.append("\n**Trade-offs and failure modes:**")
                for t in r.tradeoffs:
                    lines.append(f"- {t}")
            if r.monitoring:
                lines.append("\n**Monitor:** " + "; ".join(r.monitoring))
            if r.sources:
                lines.append("\n**Evidence:**")
                for s in r.sources:
                    finding = f" — {s.finding}" if s.finding else ""
                    lines.append(f"- {s.ref}{finding}")

    if analysis.interactions:
        lines.append("\n## How these interact")
        for x in analysis.interactions:
            lines.append(f"- {x}")
    if analysis.conflicts:
        lines.append("\n## Conflicts to resolve deliberately")
        for x in analysis.conflicts:
            lines.append(f"- {x}")

    if analysis.questions:
        lines.append("\n## To sharpen this, I need")
        for q in analysis.questions:
            lines.append(f"- **{q.question}** ({q.why_it_matters})")

    return "\n".join(lines)


def narrate(analysis: Analysis, user_message: str = "") -> str:
    """Optional model-written version of the same content. Falls back to the renderer."""
    key = ANTHROPIC_API_KEY or os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return render_markdown(analysis)
    try:
        import anthropic

        client = anthropic.Anthropic(api_key=key)
        payload = analysis.model_dump(mode="json", exclude={"retrieval"})
        msg = client.messages.create(
            model=LLM_MODEL,
            max_tokens=2000,
            system=SYSTEM,
            messages=[{
                "role": "user",
                "content": (
                    f"User said: {user_message!r}\n\n"
                    f"Engine output:\n{json.dumps(payload, indent=2)}\n\n"
                    "Write the reply."
                ),
            }],
        )
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    except Exception:  # noqa: BLE001 - never let the language layer take the system down
        return render_markdown(analysis)
