"""Typed contracts for the whole system.

Everything that crosses a module boundary is one of these objects. The reasoning
engine never sees free text, and the language layer never sees raw retrieval hits.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


class ClimateZone(str, Enum):
    arid = "arid"
    semi_arid = "semi_arid"
    sub_humid = "sub_humid"
    humid = "humid"
    temperate = "temperate"


class LandUse(str, Enum):
    cropland = "cropland"
    paddy = "paddy"
    orchard = "orchard"
    pasture = "pasture"
    forest = "forest"
    agroforestry = "agroforestry"
    wetland = "wetland"
    degraded_land = "degraded_land"
    village_commons = "village_commons"
    homestead = "homestead"


class Pressure(str, Enum):
    residue_burning = "residue_burning"
    heavy_pesticide = "heavy_pesticide"
    effluent_inflow = "effluent_inflow"
    open_grazing = "open_grazing"
    dust_deposition = "dust_deposition"
    groundwater_depletion = "groundwater_depletion"
    recent_clearing = "recent_clearing"


Horizon = Literal["short", "medium", "long"]


class SiteProfile(BaseModel):
    """Structured state of the land parcel under discussion.

    Every field is optional: the conversation layer fills slots incrementally and
    the reasoning engine degrades gracefully (and says so) on missing evidence.
    """

    land_use: LandUse | None = None
    secondary_land_use: LandUse | None = None
    climate_zone: ClimateZone | None = None
    region: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    area_ha: float | None = None

    rainfall_mm: float | None = Field(None, description="Mean annual rainfall, mm")
    rainfall_trend: str | None = None
    mean_temp_c: float | None = None

    soc_pct: float | None = Field(None, description="Soil organic carbon, % by mass, 0-30 cm")
    ph: float | None = None
    soil_moisture_status: str | None = None
    soil_texture: str | None = None
    slope_pct: float | None = None

    semi_natural_pct: float | None = Field(
        None, description="Share of the surrounding landscape under semi-natural habitat, %"
    )
    tree_density_per_ha: float | None = None
    crop: str | None = None
    cropping_pattern: str | None = None
    irrigation_source: str | None = None
    livestock: bool | None = None

    species_observations: list[str] = Field(default_factory=list)
    pressures: list[Pressure] = Field(default_factory=list)
    concerns: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)

    def known_slots(self) -> set[str]:
        out = set()
        for k, v in self.model_dump().items():
            if v not in (None, [], ""):
                out.add(k)
        return out


class SourceRef(BaseModel):
    ref: str
    finding: str | None = None


class MetricEffect(BaseModel):
    metric: str
    direction: Literal["up", "down"]
    magnitude: str | None = None
    horizon: Horizon = "medium"
    confidence: float = 0.6


class EvidenceCard(BaseModel):
    """One retrievable unit of the knowledge base."""

    id: str
    title: str
    kind: Literal["intervention", "mechanism", "context", "caution"]
    domains: list[str] = Field(default_factory=list)
    summary: str = ""
    mechanism: str = ""
    effects: list[MetricEffect] = Field(default_factory=list)
    applicability: dict[str, Any] = Field(default_factory=dict)
    prerequisites: list[str] = Field(default_factory=list)
    tradeoffs: list[str] = Field(default_factory=list)
    synergies: list[str] = Field(default_factory=list)
    conflicts: list[str] = Field(default_factory=list)
    cost: str | None = None
    reversibility: str | None = None
    sources: list[SourceRef] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)

    def embedding_text(self) -> str:
        """The text that actually gets indexed. Deliberately includes mechanism and
        tags, because queries are about *why* something works as often as *what* to do."""
        parts = [
            self.title,
            " ".join(self.domains),
            self.summary,
            self.mechanism,
            " ".join(e.metric.replace("_", " ") for e in self.effects),
            " ".join(self.tags),
            " ".join(t for t in self.tradeoffs),
        ]
        return "\n".join(p for p in parts if p)


class RetrievalHit(BaseModel):
    card_id: str
    score: float
    dense_rank: int | None = None
    lexical_rank: int | None = None
    fit_score: float = 0.0
    fit_notes: list[str] = Field(default_factory=list)
    excluded: bool = False
    exclusion_reason: str | None = None


class MetricDelta(BaseModel):
    metric: str
    direction: Literal["up", "down"]
    magnitude: str | None = None
    horizon: Horizon = "medium"
    confidence: float = 0.6
    pathway: Literal["direct", "propagated"] = "direct"
    via: list[str] = Field(default_factory=list)
    why: str | None = None


class Recommendation(BaseModel):
    card_id: str
    title: str
    action: str
    rationale: str
    metric_deltas: list[MetricDelta] = Field(default_factory=list)
    horizon: Horizon = "medium"
    confidence: float = 0.6
    confidence_basis: list[str] = Field(default_factory=list)
    prerequisites: list[str] = Field(default_factory=list)
    tradeoffs: list[str] = Field(default_factory=list)
    sources: list[SourceRef] = Field(default_factory=list)
    leverage_score: float = 0.0
    sequence_stage: int = 1
    monitoring: list[str] = Field(default_factory=list)


class Diagnosis(BaseModel):
    limiting_factors: list[str] = Field(default_factory=list)
    severity: dict[str, float] = Field(
        default_factory=dict,
        description="Per-constraint severity in [0,1]; the engine weights alignment by this "
                    "so the worst problem, not the first one detected, drives ranking.",
    )
    findings: list[str] = Field(default_factory=list)
    stop_conditions: list[str] = Field(default_factory=list)
    unknowns: list[str] = Field(default_factory=list)


class ClarifyingQuestion(BaseModel):
    slot: str
    question: str
    why_it_matters: str
    expected_type: str
    options: list[str] = Field(default_factory=list)
    information_gain: float = 0.0


class Analysis(BaseModel):
    profile: SiteProfile
    diagnosis: Diagnosis
    retrieval: list[RetrievalHit] = Field(default_factory=list)
    recommendations: list[Recommendation] = Field(default_factory=list)
    interactions: list[str] = Field(default_factory=list)
    conflicts: list[str] = Field(default_factory=list)
    questions: list[ClarifyingQuestion] = Field(default_factory=list)
    coverage: float = 0.0


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    session_id: str = "default"
    message: str = ""
    structured: dict[str, Any] | None = None


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    analysis: Analysis | None = None
    profile: SiteProfile
    asked: list[ClarifyingQuestion] = Field(default_factory=list)
