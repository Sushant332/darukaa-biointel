"""The metric ontology and its signed causal graph.

This is what makes the system multi-metric rather than multi-label. An intervention
declares the metrics it touches *directly*; the graph then propagates those effects to
metrics nobody mentioned, with an attenuating weight and an accumulating lag, and keeps
the path so the reasoning can be shown rather than asserted.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import yaml

from ..config import ONTOLOGY_PATH


@dataclass(frozen=True)
class Edge:
    src: str
    dst: str
    sign: int
    weight: float
    lag: int
    why: str


class Ontology:
    def __init__(self, path=None) -> None:
        raw = yaml.safe_load((path or ONTOLOGY_PATH).read_text(encoding="utf-8"))
        self.metrics: dict[str, dict] = raw["metrics"]
        self.edges: list[Edge] = [
            Edge(e["from"], e["to"], 1 if e["sign"] == "+" else -1,
                 float(e["weight"]), int(e["lag"]), e["why"])
            for e in raw["edges"]
        ]
        self.antagonisms: list[dict] = raw.get("antagonisms", [])
        self._out: dict[str, list[Edge]] = {}
        for e in self.edges:
            self._out.setdefault(e.src, []).append(e)

    def label(self, metric: str) -> str:
        return self.metrics.get(metric, {}).get("label", metric.replace("_", " "))

    def domain(self, metric: str) -> str:
        return self.metrics.get(metric, {}).get("domain", "other")

    def propagate(
        self,
        seeds: dict[str, int],
        max_depth: int = 3,
        min_weight: float = 0.12,
    ) -> dict[str, dict]:
        """Breadth-first propagation of signed effects.

        ``seeds`` maps metric -> +1/-1 (an improvement or a worsening). Returns
        metric -> {sign, weight, lag, path, why} for *propagated* metrics only.
        Cycles are handled by keeping the strongest path to each node and never
        revisiting a node already on the current path.
        """
        best: dict[str, dict] = {}
        frontier = [
            (m, s, 1.0, 0, [m], []) for m, s in seeds.items()
        ]
        depth = 0
        while frontier and depth < max_depth:
            nxt = []
            for node, sign, weight, lag, path, whys in frontier:
                for e in self._out.get(node, []):
                    if e.dst in path:
                        continue
                    w = weight * e.weight
                    if w < min_weight:
                        continue
                    s = sign * e.sign
                    total_lag = lag + e.lag
                    entry = best.get(e.dst)
                    if entry is None or w > entry["weight"]:
                        best[e.dst] = {
                            "sign": s,
                            "weight": round(w, 3),
                            "lag": total_lag,
                            "path": path + [e.dst],
                            "why": whys + [e.why],
                        }
                    nxt.append((e.dst, s, w, total_lag, path + [e.dst], whys + [e.why]))
            frontier = nxt
            depth += 1
        for seed in seeds:
            best.pop(seed, None)
        return best

    def horizon_for_lag(self, lag: int) -> str:
        if lag <= 2:
            return "short"
        if lag <= 6:
            return "medium"
        return "long"


@lru_cache(maxsize=1)
def get_ontology() -> Ontology:
    return Ontology()
