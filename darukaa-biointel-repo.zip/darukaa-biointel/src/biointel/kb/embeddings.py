"""Dense encoders.

Two backends behind one interface:

* ``SentenceTransformerEncoder`` — the production path (all-MiniLM-L6-v2 by default).
* ``HashedNgramEncoder``       — a dependency-free, fully deterministic fallback that
  hashes character 3-5 grams and word unigrams into a fixed-width vector, then
  L2-normalises. It is weaker than a trained encoder but it is reproducible, needs
  no model download, and keeps CI and offline demos honest instead of skipped.

The retriever never cares which one is active; it only reads ``.name``.
"""
from __future__ import annotations

import hashlib
import re
from typing import Protocol

import numpy as np

from ..config import EMBED_MODEL, USE_ST

_WORD = re.compile(r"[a-z0-9]+")


class Encoder(Protocol):
    name: str
    dim: int

    def encode(self, texts: list[str]) -> np.ndarray: ...


class HashedNgramEncoder:
    name = "hashed-ngram-fallback"

    def __init__(self, dim: int = 768) -> None:
        self.dim = dim

    def _tokens(self, text: str) -> list[str]:
        low = text.lower()
        words = _WORD.findall(low)
        toks: list[str] = list(words)
        toks += [f"{a}_{b}" for a, b in zip(words, words[1:], strict=False)]
        padded = " " + " ".join(words) + " "
        for n in (3, 4, 5):
            toks += [padded[i : i + n] for i in range(0, max(0, len(padded) - n), 2)]
        return toks

    def encode(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for row, text in enumerate(texts):
            for tok in self._tokens(text):
                h = hashlib.blake2b(tok.encode(), digest_size=8).digest()
                idx = int.from_bytes(h[:4], "big") % self.dim
                sign = 1.0 if h[4] & 1 else -1.0
                # sublinear damping keeps frequent character grams from dominating
                out[row, idx] += sign
        norms = np.linalg.norm(out, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return out / norms


class SentenceTransformerEncoder:
    def __init__(self, model_name: str = EMBED_MODEL) -> None:
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(model_name)
        self.name = model_name
        self.dim = int(self._model.get_sentence_embedding_dimension())

    def encode(self, texts: list[str]) -> np.ndarray:
        vecs = self._model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return np.asarray(vecs, dtype=np.float32)


def get_encoder() -> Encoder:
    if USE_ST == "no":
        return HashedNgramEncoder()
    try:
        return SentenceTransformerEncoder()
    except Exception:
        if USE_ST == "yes":
            raise
        return HashedNgramEncoder()
