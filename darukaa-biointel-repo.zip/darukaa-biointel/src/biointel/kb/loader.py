"""Load and validate the YAML evidence corpus into typed EvidenceCard objects."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import yaml

from ..config import KB_DIR
from ..schemas import EvidenceCard


def _load_file(path: Path) -> list[EvidenceCard]:
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    cards = []
    for item in raw.get("cards", []):
        item.setdefault("domains", [])
        cards.append(EvidenceCard.model_validate(item))
    return cards


@lru_cache(maxsize=1)
def load_cards(kb_dir: str | None = None) -> tuple[EvidenceCard, ...]:
    directory = Path(kb_dir) if kb_dir else KB_DIR
    cards: list[EvidenceCard] = []
    for path in sorted(directory.glob("*.yaml")):
        cards.extend(_load_file(path))
    ids = [c.id for c in cards]
    dupes = {i for i in ids if ids.count(i) > 1}
    if dupes:
        raise ValueError(f"Duplicate card ids in knowledge base: {sorted(dupes)}")
    # Referential integrity: synergies/conflicts must point at real cards.
    known = set(ids)
    for c in cards:
        for ref in list(c.synergies) + list(c.conflicts):
            if ref not in known:
                raise ValueError(f"Card {c.id} references unknown card {ref}")
    return tuple(cards)


def card_index() -> dict[str, EvidenceCard]:
    return {c.id: c for c in load_cards()}
