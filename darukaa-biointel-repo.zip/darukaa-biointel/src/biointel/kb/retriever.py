"""Retrieval: hybrid dense + lexical fusion, then site-conditioned gating.

Three stages, each observable in the API response so the pipeline can be audited
rather than taken on trust:

1. **Recall** — dense cosine search and BM25 run independently over the same corpus.
2. **Fusion** — Reciprocal Rank Fusion merges the two rankings. RRF is used instead of
   score normalisation because BM25 and cosine scores are not on comparable scales and
   RRF is robust to that without tuning.
3. **Gating** — the structured ``SiteProfile`` is applied as a hard filter and a soft
   fit score. A card whose applicability window excludes the site is *excluded with a
   stated reason*, not silently down-ranked. This is what stops the system from
   recommending liming on an alkaline soil because the text happened to match.
"""
from __future__ import annotations

import contextlib

from ..config import TOP_K_DENSE, TOP_K_FINAL, TOP_K_LEXICAL
from ..schemas import EvidenceCard, RetrievalHit, SiteProfile
from .loader import load_cards
from .vector_store import VectorStore

RRF_K = 60.0


def _numeric_gate(
    window: dict, value: float | None, label: str
) -> tuple[bool, str | None, float]:
    """Return (passes, reason_if_failed, fit_contribution)."""
    if value is None:
        return True, None, 0.0  # unknown: do not exclude, but earn no fit credit
    lo, hi = window.get("min"), window.get("max")
    if lo is not None and value < lo:
        return False, f"{label} {value} is below this card's applicable minimum of {lo}", 0.0
    if hi is not None and value > hi:
        return False, f"{label} {value} is above this card's applicable maximum of {hi}", 0.0
    return True, None, 1.0


def score_fit(card: EvidenceCard, profile: SiteProfile) -> tuple[float, list[str], str | None]:
    """Soft fit in [0,1] plus a hard exclusion reason when the site falls outside the window."""
    app = card.applicability or {}
    notes: list[str] = []
    credits: list[float] = []

    if profile.land_use and app.get("land_use"):
        allowed = set(app["land_use"])
        uses = {profile.land_use.value}
        if profile.secondary_land_use:
            uses.add(profile.secondary_land_use.value)
        if not (uses & allowed):
            return 0.0, notes, (
                f"land use '{profile.land_use.value}' is outside this card's scope "
                f"({', '.join(sorted(allowed))})"
            )
        notes.append(f"applies to {profile.land_use.value}")
        credits.append(1.0)

    if profile.climate_zone and app.get("climate"):
        if profile.climate_zone.value not in set(app["climate"]):
            return 0.0, notes, (
                f"climate zone '{profile.climate_zone.value}' is outside this card's scope"
            )
        notes.append(f"validated for {profile.climate_zone.value} conditions")
        credits.append(1.0)

    for key, value, label in (
        ("soc_pct", profile.soc_pct, "soil organic carbon"),
        ("ph", profile.ph, "pH"),
        ("rainfall_mm", profile.rainfall_mm, "rainfall"),
        ("slope_pct", profile.slope_pct, "slope"),
        ("semi_natural_pct", profile.semi_natural_pct, "semi-natural habitat share"),
    ):
        window = app.get(key)
        if not window:
            continue
        ok, reason, credit = _numeric_gate(window, value, label)
        if not ok:
            return 0.0, notes, reason
        if credit:
            notes.append(f"{label} {value} falls inside the card's evidence window")
        credits.append(credit)

    base = sum(credits) / len(credits) if credits else 0.35
    return base, notes, None


def _rrf(rankings: list[list[str]]) -> dict[str, float]:
    out: dict[str, float] = {}
    for ranking in rankings:
        for rank, cid in enumerate(ranking):
            out[cid] = out.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)
    return out


class Retriever:
    def __init__(self, store: VectorStore | None = None) -> None:
        self.cards = {c.id: c for c in load_cards()}
        self.store = store or VectorStore()
        if self.store.matrix is None and not self.store.load():
            ids = list(self.cards)
            self.store.build(ids, [self.cards[i].embedding_text() for i in ids])
            with contextlib.suppress(OSError):   # a read-only FS must not break startup
                self.store.save()

    @property
    def encoder_name(self) -> str:
        return self.store.encoder.name

    def search(
        self,
        query: str,
        profile: SiteProfile | None = None,
        k: int = TOP_K_FINAL,
        include_excluded: bool = True,
    ) -> list[RetrievalHit]:
        profile = profile or SiteProfile()
        dense = self.store.dense_search(query, TOP_K_DENSE)
        lexical = self.store.lexical_search(query, TOP_K_LEXICAL)
        dense_rank = {cid: i for i, (cid, _) in enumerate(dense)}
        lex_rank = {cid: i for i, (cid, _) in enumerate(lexical)}
        fused = _rrf([[c for c, _ in dense], [c for c, _ in lexical]])

        hits: list[RetrievalHit] = []
        for cid, fusion_score in fused.items():
            card = self.cards[cid]
            fit, notes, exclusion = score_fit(card, profile)
            hits.append(
                RetrievalHit(
                    card_id=cid,
                    score=round(fusion_score * (0.4 + 0.6 * fit), 6),
                    dense_rank=dense_rank.get(cid),
                    lexical_rank=lex_rank.get(cid),
                    fit_score=round(fit, 3),
                    fit_notes=notes,
                    excluded=exclusion is not None,
                    exclusion_reason=exclusion,
                )
            )
        hits.sort(key=lambda h: (h.excluded, -h.score))
        kept = [h for h in hits if not h.excluded][:k]
        if include_excluded:
            kept += [h for h in hits if h.excluded][:3]
        return kept

    def multi_query(
        self, queries: list[str], profile: SiteProfile | None = None, k: int = TOP_K_FINAL
    ) -> list[RetrievalHit]:
        """Fan out over several framings of the problem and fuse again.

        A site description implies several sub-questions (soil, water, habitat, pressure).
        Issuing them separately and fusing recovers cards a single blended query misses.
        """
        pooled: dict[str, RetrievalHit] = {}
        for q in queries:
            for hit in self.search(q, profile, k=k, include_excluded=True):
                prev = pooled.get(hit.card_id)
                if prev is None or hit.score > prev.score:
                    pooled[hit.card_id] = hit
        out = sorted(pooled.values(), key=lambda h: (h.excluded, -h.score))
        return out[: k + 6]
