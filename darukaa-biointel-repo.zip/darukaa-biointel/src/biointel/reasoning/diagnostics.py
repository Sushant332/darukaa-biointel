"""Diagnosis before prescription.

The engine first decides *what is limiting this site*, because the same intervention is
excellent or useless depending on the binding constraint. Rules are explicit and
inspectable rather than learned, which is what allows every downstream recommendation to
carry a stated reason.

Each rule returns (limiting_factor, finding) and rules may also raise a *stop condition*:
a pressure that will negate ecological investment until it is dealt with.
"""
from __future__ import annotations

from ..schemas import ClimateZone, Diagnosis, LandUse, Pressure, SiteProfile


def _flag(d: Diagnosis, factor: str, severity: float) -> None:
    """Record a constraint with a severity, keeping the worst reading if flagged twice."""
    d.limiting_factors.append(factor)
    d.severity[factor] = max(d.severity.get(factor, 0.0), severity)

# --- limiting-factor rules ------------------------------------------------


def _carbon(p: SiteProfile, d: Diagnosis) -> None:
    if p.soc_pct is None:
        d.unknowns.append("soil_organic_carbon")
        return
    if p.soc_pct < 0.5:
        _flag(d, "carbon_depletion", 0.9)
        d.findings.append(
            f"Soil organic carbon at {p.soc_pct}% is below the ~0.5% threshold at which "
            "aggregate stability and biological function collapse. This is the site's "
            "structural constraint, not a nutrient problem."
        )
    elif p.soc_pct < 0.75:
        _flag(d, "carbon_depletion", 0.55)
        d.findings.append(
            f"Soil organic carbon at {p.soc_pct}% is degraded but responsive; carbon "
            "practices will show a measurable return here."
        )
    elif p.soc_pct >= 1.0:
        d.findings.append(
            f"Soil organic carbon at {p.soc_pct}% is functional. If biodiversity is still "
            "declining, carbon is not the binding constraint and the cause is more likely "
            "habitat structure, connectivity or a chemical pressure."
        )


def _acidity(p: SiteProfile, d: Diagnosis) -> None:
    if p.ph is None:
        d.unknowns.append("ph")
        return
    if p.ph < 5.5:
        _flag(d, "acidity_aluminium", 1.0)
        d.findings.append(
            f"pH {p.ph} puts the soil in the aluminium-toxicity range. Root depth is capped, "
            "which caps water access, and rhizobial nodulation is suppressed - so any legume "
            "or cover-crop strategy will underperform until this is corrected."
        )
    elif p.ph > 8.4:
        _flag(d, "sodicity_alkalinity", 1.0)
        d.findings.append(
            f"pH {p.ph} indicates alkaline and probably sodic conditions. Clay dispersion, not "
            "rainfall, is likely to be the reason water does not enter the profile."
        )


def _water(p: SiteProfile, d: Diagnosis) -> None:
    if p.climate_zone is None and p.rainfall_mm is None:
        d.unknowns.append("climate_zone")
        return
    arid = p.climate_zone in (ClimateZone.arid, ClimateZone.semi_arid)
    low_rain = p.rainfall_mm is not None and p.rainfall_mm < 800
    if arid or low_rain:
        _flag(d, "water_limitation", 0.7)
        d.findings.append(
            "Water is the dominant intermittent constraint. Interventions are therefore "
            "judged on whether they increase infiltration and retention, and any measure "
            "that adds transpiring biomass must be justified against the crop water budget."
        )
    if Pressure.groundwater_depletion in p.pressures:
        _flag(d, "aquifer_overdraft", 0.95)
        d.findings.append(
            "Groundwater is being drawn down. Under overdraft, upstream water harvesting "
            "largely redistributes water within a closed basin rather than creating it; the "
            "effective lever is reducing abstraction, which means changing the crop, not the "
            "irrigation hardware."
        )


def _habitat(p: SiteProfile, d: Diagnosis) -> None:
    if p.semi_natural_pct is None:
        d.unknowns.append("semi_natural_pct")
    elif p.semi_natural_pct < 10:
        _flag(d, "species_pool_depletion", 0.95)
        d.findings.append(
            f"With only {p.semi_natural_pct}% semi-natural habitat in the surrounding landscape, "
            "the regional species pool is the constraint. Field-scale measures will be colonised "
            "slowly or not at all, so a source patch and connectivity have to come first."
        )
    elif p.semi_natural_pct < 25:
        _flag(d, "connectivity_limitation", 0.6)
        d.findings.append(
            f"At {p.semi_natural_pct}% semi-natural habitat the landscape is simplified but not "
            "emptied. This is where field-scale interventions give their highest marginal return, "
            "provided they connect to the remaining patches rather than sitting in isolation."
        )

    if p.cropping_pattern and "mono" in p.cropping_pattern.lower():
        _flag(d, "structural_simplicity", 0.7)
        d.findings.append(
            "Continuous monoculture provides one vertical layer and one phenological event per "
            "year. Most of the missing species are missing because the niches are absent, which "
            "no amount of soil amendment will restore."
        )
    if p.tree_density_per_ha is not None and p.tree_density_per_ha < 5:
        _flag(d, "structural_simplicity", 0.7)
        d.findings.append(
            f"Tree density of {p.tree_density_per_ha}/ha means canopy-dependent guilds "
            "(bark gleaners, cavity nesters, canopy insectivores) have no habitat on site."
        )
    if p.land_use == LandUse.degraded_land:
        _flag(d, "surface_degradation", 0.85)
        d.findings.append(
            "On degraded land the first failure is usually infiltration at a crusted surface, "
            "not fertility; restoring entry of water precedes restoring vegetation."
        )


def _pressures(p: SiteProfile, d: Diagnosis) -> None:
    mapping = {
        Pressure.residue_burning: (
            "Annual residue burning resets surface soil biology every season and removes the "
            "carbon input that every soil recommendation depends on. Nothing else will hold "
            "while burning continues."
        ),
        Pressure.heavy_pesticide: (
            "High or calendar-based pesticide use will negate pollinator and natural-enemy "
            "interventions. Habitat features installed alongside prophylactic spraying are "
            "wasted expenditure."
        ),
        Pressure.effluent_inflow: (
            "Untreated effluent entering the water body exceeds what a vegetated buffer can "
            "process. Aquatic restoration downstream of an active discharge will not hold."
        ),
        Pressure.open_grazing: (
            "Uncontrolled grazing is the most common cause of failure in regeneration and "
            "planting programmes; establishment protection has to be agreed before planting."
        ),
        Pressure.dust_deposition: (
            "Chronic dust deposition from a quarry, kiln or highway suppresses leaf "
            "photosynthesis and alters arthropod communities along a several-hundred-metre "
            "gradient; site habitat features away from that gradient."
        ),
        Pressure.recent_clearing: (
            "Recent habitat conversion is by far the most probable cause of a recent "
            "biodiversity decline; treat it as the working hypothesis before looking at soil "
            "chemistry (IPBES 2019 driver ranking)."
        ),
    }
    for pressure in p.pressures:
        if pressure in mapping:
            d.stop_conditions.append(mapping[pressure])


RULES = (_carbon, _acidity, _water, _habitat, _pressures)


def diagnose(profile: SiteProfile) -> Diagnosis:
    d = Diagnosis()
    for rule in RULES:
        rule(profile, d)
    # deduplicate while preserving order
    # order by severity so downstream code can treat the head as the primary constraint
    d.limiting_factors = sorted(
        dict.fromkeys(d.limiting_factors), key=lambda f: -d.severity.get(f, 0.5)
    )
    d.unknowns = list(dict.fromkeys(d.unknowns))
    return d
