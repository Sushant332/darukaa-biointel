"""Behavioural tests.

These assert on *reasoning properties*, not on exact strings: that the system refuses to
recommend liming an alkaline soil, that it puts a stop condition ahead of a plan, that a
causal sign composes correctly along a path. Those are the things that would make the
system wrong in a way a user could not detect.
"""
from __future__ import annotations

import pytest

from biointel.conversation.agent import BioIntelAgent
from biointel.conversation.state import extract_slots
from biointel.kb.loader import load_cards
from biointel.kb.retriever import Retriever, score_fit
from biointel.reasoning.diagnostics import diagnose
from biointel.reasoning.engine import analyse
from biointel.reasoning.ontology import get_ontology
from biointel.schemas import ClimateZone, LandUse, Pressure, SiteProfile


@pytest.fixture(scope="module")
def retriever():
    return Retriever()


# --- knowledge base integrity ---------------------------------------------

def test_corpus_loads_and_is_referentially_sound():
    cards = load_cards()
    assert len(cards) >= 30
    ids = {c.id for c in cards}
    for c in cards:
        for ref in list(c.synergies) + list(c.conflicts):
            assert ref in ids


def test_every_intervention_is_cited_and_has_effects():
    for c in load_cards():
        if c.kind == "intervention":
            assert c.sources, f"{c.id} has no source"
            assert c.effects, f"{c.id} declares no metric effect"
            assert c.mechanism.strip(), f"{c.id} has no mechanism"


def test_every_declared_metric_exists_in_the_ontology():
    onto = get_ontology()
    for c in load_cards():
        for e in c.effects:
            assert e.metric in onto.metrics, f"{c.id} references unknown metric {e.metric}"


# --- retrieval gating ------------------------------------------------------

def test_alkaline_site_excludes_liming(retriever):
    profile = SiteProfile(ph=8.7, land_use=LandUse.cropland, climate_zone=ClimateZone.semi_arid)
    hits = retriever.search("raise soil pH improve microbial diversity liming", profile, k=8)
    lime = next((h for h in hits if h.card_id == "INT-LIME-ACID"), None)
    if lime is not None:
        # Excluded on climate window or on pH window - either is a correct refusal,
        # but it must be a *stated* one.
        assert lime.excluded and lime.exclusion_reason
    analysis = analyse(profile, "how do I fix my soil", retriever=retriever)
    assert "INT-LIME-ACID" not in {r.card_id for r in analysis.recommendations}


def test_paddy_does_not_get_dryland_pit_advice(retriever):
    profile = SiteProfile(land_use=LandUse.paddy, climate_zone=ClimateZone.humid, rainfall_mm=1800)
    analysis = analyse(profile, "improve biodiversity in my rice fields", retriever=retriever)
    ids = {r.card_id for r in analysis.recommendations}
    assert "INT-ZAI-DEMILUNE" not in ids


def test_exclusions_carry_a_stated_reason(retriever):
    profile = SiteProfile(land_use=LandUse.paddy, climate_zone=ClimateZone.humid)
    hits = retriever.search("zai pits dryland restoration", profile, k=8)
    for h in hits:
        if h.excluded:
            assert h.exclusion_reason


def test_hybrid_retrieval_recovers_exact_technical_terms(retriever):
    hits = retriever.search("Faidherbia albida reverse phenology parkland", k=5)
    assert "INT-AGROFORESTRY" in {h.card_id for h in hits}
    hits = retriever.search("neonicotinoid seed treatment", k=5)
    assert "INT-IPM-PESTICIDE" in {h.card_id for h in hits}


def test_fit_score_rewards_matching_conditions():
    card = next(c for c in load_cards() if c.id == "INT-ZAI-DEMILUNE")
    good = SiteProfile(land_use=LandUse.degraded_land, climate_zone=ClimateZone.semi_arid,
                       rainfall_mm=450, soc_pct=0.3)
    fit, _, excl = score_fit(card, good)
    assert excl is None and fit > 0.9
    bad = SiteProfile(land_use=LandUse.degraded_land, climate_zone=ClimateZone.humid)
    _, _, excl = score_fit(card, bad)
    assert excl is not None


# --- diagnosis -------------------------------------------------------------

def test_low_carbon_is_diagnosed_as_the_binding_constraint():
    d = diagnose(SiteProfile(soc_pct=0.3, climate_zone=ClimateZone.semi_arid))
    assert "carbon_depletion" in d.limiting_factors


def test_healthy_carbon_is_not_treated_as_a_carbon_problem():
    d = diagnose(SiteProfile(soc_pct=1.6, climate_zone=ClimateZone.humid, semi_natural_pct=5))
    assert "carbon_depletion" not in d.limiting_factors
    assert "species_pool_depletion" in d.limiting_factors


def test_pressures_become_stop_conditions():
    d = diagnose(SiteProfile(pressures=[Pressure.residue_burning, Pressure.heavy_pesticide]))
    assert len(d.stop_conditions) == 2


def test_unknowns_are_recorded_rather_than_assumed():
    d = diagnose(SiteProfile(land_use=LandUse.cropland))
    assert "soil_organic_carbon" in d.unknowns and "ph" in d.unknowns


# --- causal propagation ----------------------------------------------------

def test_signs_compose_along_a_causal_path():
    onto = get_ontology()
    # Lowering erosion (value down) must raise water quality, via a negative edge.
    out = onto.propagate({"erosion_rate": -1})
    assert out["water_quality"]["sign"] > 0
    # Raising vegetation cover lowers erosion and therefore also raises water quality.
    out = onto.propagate({"vegetation_cover": 1})
    assert out["erosion_rate"]["sign"] < 0
    assert out["water_quality"]["sign"] > 0


def test_propagation_is_acyclic_and_lagged():
    onto = get_ontology()
    out = onto.propagate({"soil_organic_carbon": 1})
    for info in out.values():
        assert len(set(info["path"])) == len(info["path"])
        assert info["lag"] >= 1


def test_recommendations_are_multi_metric(retriever):
    profile = SiteProfile(land_use=LandUse.cropland, climate_zone=ClimateZone.semi_arid,
                          soc_pct=0.3, rainfall_mm=420, cropping_pattern="monoculture")
    analysis = analyse(profile, "biodiversity is declining", retriever=retriever)
    onto = get_ontology()
    for r in analysis.recommendations:
        domains = {onto.domain(d.metric) for d in r.metric_deltas}
        assert len(domains) >= 2, f"{r.card_id} is single-domain"
        assert any(d.pathway == "propagated" for d in r.metric_deltas)


def test_every_recommendation_carries_evidence_and_a_horizon(retriever):
    profile = SiteProfile(land_use=LandUse.cropland, climate_zone=ClimateZone.semi_arid, soc_pct=0.4)
    analysis = analyse(profile, "what should I do", retriever=retriever)
    assert analysis.recommendations
    for r in analysis.recommendations:
        assert r.sources
        assert r.horizon in ("short", "medium", "long")
        assert 0.0 < r.confidence <= 0.95
        assert r.rationale.strip()


def test_stop_conditions_outrank_optimisation(retriever):
    profile = SiteProfile(land_use=LandUse.cropland, climate_zone=ClimateZone.semi_arid,
                          soc_pct=0.3, pressures=[Pressure.residue_burning])
    analysis = analyse(profile, "improve biodiversity", retriever=retriever)
    assert analysis.diagnosis.stop_conditions
    assert analysis.recommendations[0].sequence_stage == 1


# --- input handling & conversation ----------------------------------------

def test_free_text_extraction():
    slots = extract_slots(
        "I have 5 acres of semi-arid cropland, organic carbon 0.4%, pH 5.2, "
        "rainfall about 600 mm, monoculture maize, and we burn the stubble"
    )
    assert slots["soc_pct"] == 0.4
    assert slots["ph"] == 5.2
    assert slots["rainfall_mm"] == 600
    assert slots["climate_zone"] == ClimateZone.semi_arid
    assert slots["cropping_pattern"] == "monoculture"
    assert Pressure.residue_burning in slots["pressures"]
    assert abs(slots["area_ha"] - 2.02) < 0.05


def test_geo_coordinates_are_parsed():
    slots = extract_slots("my plot is at 26.91, 75.78 in Rajasthan")
    assert abs(slots["latitude"] - 26.91) < 0.01
    assert abs(slots["longitude"] - 75.78) < 0.01


def test_memory_persists_and_corrections_are_journalled():
    agent = BioIntelAgent()
    agent.handle("t", "semi-arid cropland with organic carbon 0.3%")
    agent.handle("t", "actually the organic carbon is 0.9%")
    assert agent.profile("t").soc_pct == 0.9
    assert agent.profile("t").climate_zone == ClimateZone.semi_arid  # retained across turns
    journal = agent.store.get("t").journal
    assert any("updated" in c for entry in journal for c in entry["changes"])


def test_structured_input_merges_with_free_text():
    agent = BioIntelAgent()
    agent.handle("u", "biodiversity is declining")
    agent.handle("u", "", {"land_use": "orchard", "ph": 6.4, "soc_pct": 0.8, "bogus_field": 1})
    p = agent.profile("u")
    assert p.land_use == LandUse.orchard and p.ph == 6.4
    assert any("ignored unrecognised" in c for e in agent.store.get("u").journal for c in e["changes"])


def test_vague_opening_triggers_high_gain_questions():
    agent = BioIntelAgent()
    result = agent.handle("v", "Biodiversity is declining on my land")
    assert result.questions
    assert all(q.information_gain > 0 for q in result.questions)
    assert all(q.why_it_matters for q in result.questions)


def test_questions_are_not_repeated():
    agent = BioIntelAgent()
    first = {q.slot for q in agent.handle("w", "my land is degrading").questions}
    second = {q.slot for q in agent.handle("w", "tell me more").questions}
    assert not (first & second)


def test_information_gain_is_low_for_irrelevant_slots():
    """On a well-specified paddy, slope should carry less information than habitat share."""
    agent = BioIntelAgent()
    profile = SiteProfile(land_use=LandUse.paddy, climate_zone=ClimateZone.humid,
                          rainfall_mm=1800, soc_pct=1.2, ph=6.5)
    baseline = analyse(profile, "improve biodiversity", retriever=agent.retriever)
    slope_gain = agent.information_gain(profile, "improve biodiversity", "slope_pct", baseline)
    habitat_gain = agent.information_gain(profile, "improve biodiversity", "semi_natural_pct", baseline)
    assert habitat_gain >= slope_gain


# --- output contract -------------------------------------------------------

def test_conflicts_are_surfaced_not_hidden(retriever):
    profile = SiteProfile(land_use=LandUse.cropland, climate_zone=ClimateZone.semi_arid,
                          soc_pct=0.3, semi_natural_pct=6, rainfall_mm=450)
    analysis = analyse(profile, "improve biodiversity and yields", retriever=retriever)
    assert analysis.interactions or analysis.conflicts


def test_rendered_output_contains_the_four_mandatory_parts(retriever):
    from biointel.llm.client import render_markdown

    profile = SiteProfile(land_use=LandUse.cropland, climate_zone=ClimateZone.semi_arid, soc_pct=0.3)
    md = render_markdown(analyse(profile, "biodiversity declining", retriever=retriever))
    for part in ("What to do", "Why it works", "Metrics that move", "Time horizon",
                 "Confidence", "Evidence"):
        assert part in md
